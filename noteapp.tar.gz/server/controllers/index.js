const users = require('./users');
const noteItems = require('./noteitems');

module.exports = {
  users,
  noteItems,
};
